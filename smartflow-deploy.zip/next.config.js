/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['smartflowafrica.com', 'images.unsplash.com'],
    formats: ['image/webp', 'image/avif'],
  },
}

module.exports = nextConfig
