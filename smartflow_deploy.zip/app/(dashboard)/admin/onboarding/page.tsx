import { OnboardingWizard } from '@/components/admin/onboarding/OnboardingWizard';

export default function OnboardingPage() {
    return <OnboardingWizard />;
}
